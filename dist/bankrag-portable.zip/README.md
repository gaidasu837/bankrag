# 工商银行 GraphRAG 问答知识库（证据链优先）

新电脑请阅读 [完整安装教程](INSTALL_WINDOWS.md)。数据库在 `dist/bankrag-portable.zip` 内，先解压再导入。

本项目用于构建一个面向工商银行公开业务资料的问答系统。首版聚焦个人银行业务，所有可对外展示的回答都必须携带可核验的证据链。

## 核心原则

系统只允许使用列入来源清单的官方资料。每个回答必须包含：

1. 结论；
2. 支撑结论的原文片段；
3. 文档标题与官方 URL；
4. 页面发布日期（若官方提供）与采集时间；
5. 证据与结论之间的关系；
6. 时效性和适用范围提示。

如果证据不足、互相冲突或可能已过期，系统应拒绝给出确定答案，并引导用户通过工行官方渠道核验。

## 目录

```text
config/sources.yaml       官方来源白名单
schemas/                  文档、片段和回答的数据结构
src/bankrag/              导入、检索和证据链校验代码
data/raw/                 原始网页快照（后续采集）
data/processed/           清洗后的文档与片段
tests/                    自动化测试
```

## 首版范围

- 个人账户与银行卡
- 存款与贷款
- 转账汇款与支付缴费
- 手机银行、网上银行及安全操作
- 业务协议与办理规则
- 官方热点问答

投资建议、个性化授信判断、实时余额、实时利率和客户个人信息不在公开知识库回答范围内。

## 快速验证

本仓库的基础校验不依赖第三方包：

```powershell
python -m unittest discover -s tests -v
```

## 2026-09-08 首批入库

数据库为 `data/icbc.sqlite3`（SQLite），采集报告为 `data/collection_report.json`。
`documents` 保存版本、官方地址、网页发布日期（未提供则为空）、采集时间、原始网页路径和 SHA-256；`chunks` 保存正文片段及字符起止位置；`fetch_log` 记录成功和失败。
原始 HTML 以内容哈希命名，重复采集相同内容不会覆盖历史版本。全文保留重复段落，避免改变条款含义。

```powershell
$env:PYTHONPATH='src'
python -m bankrag.collect --verify
python -m bankrag.collect --query 提前支取
python -m bankrag.collect --limit 25
```

首批资料均为 `pending_review`：官网发布日不等于规则生效日，正文仍可能包含导航、旧规则和分行适用限制。查询目前返回原文候选及来源，不生成正式业务结论。协议目录不等于协议附件已采集；PDF附件尚未导入。

现有 `evidence.py` 仅检查字段和域名，尚不能验证结论是否被原文支持、资料是否过期或相互冲突。数据库哈希/片段校验已经实现，但完整问答证据校验、GraphRAG实体关系抽取和向量索引尚待实现。
